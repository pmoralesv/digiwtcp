Pentru cuplare PC <--> SM-100 pe TCP/IP, cititi fisierul SM100_Ethernet.doc



"sendplu.bat" este un exemplu de linie de comanda pentru transmiterea de coduri (in fisierul plu.dat) la cantarul cu adresa IP 192.168.1.101, folosind DIGIWTCP.
"send101.bat" este un exemplu de linie de comanda pentru transmiterea de coduri (in fisierul plu.dat) la cantarul cu adresa IP 192.168.1.101, folosind TWSWTCP.

Pentru modificarea adresei IP a cantarulu, cititi "Programare_IP_Adress_SM100.doc"

Pentru re-programarea formatului de eticheta, numelui de magazin si mesajelor de scroll in urma unei operatii de Clear Memory se folosesc :
 - utilizand DIGIWTCP, "sendlf.bat", "sendshop.bat" si "sendscroll.bat"
 - utilizand TWSWTCP, "init101.bat"

